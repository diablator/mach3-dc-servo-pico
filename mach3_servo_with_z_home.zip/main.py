
import machine
import time
import utime
import ssd1306
import _thread

# === OLED ekran ===
i2c = machine.I2C(0, scl=machine.Pin(9), sda=machine.Pin(8))
oled = ssd1306.SSD1306_I2C(128, 64, i2c)

# === Motor Çıkışları (BTS7960) ===
pwm1 = machine.PWM(machine.Pin(5))
pwm2 = machine.PWM(machine.Pin(6))
pwm1.freq(1000)
pwm2.freq(1000)

# === Encoder girişleri (Quadrature) ===
enc_a = machine.Pin(2, machine.Pin.IN, machine.Pin.PULL_UP)
enc_b = machine.Pin(3, machine.Pin.IN, machine.Pin.PULL_UP)

# === Step/Dir Girişleri (Mach3) ===
step_pin = machine.Pin(14, machine.Pin.IN, machine.Pin.PULL_DOWN)
dir_pin = machine.Pin(15, machine.Pin.IN, machine.Pin.PULL_DOWN)

# === Z referans pini ===
z_pin = machine.Pin(10, machine.Pin.IN, machine.Pin.PULL_UP)

# === Global değişkenler ===
position = 0
target_position = 0
last_state = (enc_a.value() << 1) | enc_b.value()
position_lock = _thread.allocate_lock()

# === PID Parametreleri ===
Kp = 1.2
Ki = 0.01
Kd = 0.1
integral = 0.0
last_error = 0.0

# === Step sinyali işle ===
def step_irq(pin):
    global target_position
    direction = dir_pin.value()
    with position_lock:
        if direction:
            target_position += 1
        else:
            target_position -= 1

step_pin.irq(trigger=machine.Pin.IRQ_RISING, handler=step_irq)

# === Quadrature Encoder ===
transition_table = [
  [ 0, -1,  1,  0],
  [ 1,  0,  0, -1],
  [-1,  0,  0,  1],
  [ 0,  1, -1,  0]
]

def encoder_irq(pin):
    global position, last_state
    A = enc_a.value()
    B = enc_b.value()
    current_state = (A << 1) | B
    movement = transition_table[last_state][current_state]
    last_state = current_state
    with position_lock:
        position += movement

enc_a.irq(trigger=machine.Pin.IRQ_RISING | machine.Pin.IRQ_FALLING, handler=encoder_irq)
enc_b.irq(trigger=machine.Pin.IRQ_RISING | machine.Pin.IRQ_FALLING, handler=encoder_irq)

# === PID Kontrol ===
def pid_update(timer):
    global integral, last_error, position

    # Z referans tetiklenirse pozisyon sıfırla
    if z_pin.value() == 0:
        with position_lock:
            position = 0

    with position_lock:
        pos = position
        target = target_position

    error = target - pos
    integral += error
    integral = max(min(integral, 1000), -1000)
    derivative = error - last_error
    last_error = error

    output = Kp * error + Ki * integral + Kd * derivative
    pwm_val = int(min(abs(output), 65535))

    if output > 0:
        pwm1.duty_u16(pwm_val)
        pwm2.duty_u16(0)
    elif output < 0:
        pwm1.duty_u16(0)
        pwm2.duty_u16(pwm_val)
    else:
        pwm1.duty_u16(0)
        pwm2.duty_u16(0)

# === OLED Güncelle ===
def oled_task():
    while True:
        with position_lock:
            p = position
            t = target_position
        oled.fill(0)
        oled.text("Target: {}".format(t), 0, 0)
        oled.text("Pos:    {}".format(p), 0, 16)
        oled.text("Dir: {}".format(dir_pin.value()), 0, 32)
        oled.text("Z: {}".format(z_pin.value()), 0, 48)
        oled.show()
        utime.sleep_ms(250)

# === Başlat ===
pid_timer = machine.Timer()
pid_timer.init(period=10, mode=machine.Timer.PERIODIC, callback=pid_update)

_thread.start_new_thread(oled_task, ())

while True:
    time.sleep(1)
