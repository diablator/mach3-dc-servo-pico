
import machine
import utime

# === Ayarlar ===
comm_pin = machine.Pin(12, machine.Pin.IN, machine.Pin.PULL_UP)

# === Zaman eşiği (ms cinsinden) ===
BIT_0_MAX = 2
BIT_1_MIN = 3
BIT_1_MAX = 5
LETTER_GAP_MIN = 8
COMMAND_GAP_MIN = 20

# === Kod çözümleme ===
decoded_bits = ""
decoded_command = ""

# UART simülasyonu
def handle_command(cmd):
    print("Komut alındı:", cmd)
    if cmd == "M210":
        print("EEPROM'a kaydedilecek")
    elif cmd == "M211":
        print("EEPROM'dan yüklenecek")
    elif cmd == "M220":
        print("PID tuning başlatılacak")
    else:
        print("Bilinmeyen komut")

# Bit dizisini ASCII karaktere çevir
def bits_to_char(bits):
    try:
        return chr(int(bits, 2))
    except:
        return "?"

# Pulse okuma döngüsü
def read_pulses():
    global decoded_bits, decoded_command
    last_time = utime.ticks_ms()
    while True:
        while comm_pin.value() == 1:
            pass
        while comm_pin.value() == 0:
            pass
        now = utime.ticks_ms()
        duration = utime.ticks_diff(now, last_time)
        last_time = now

        if duration < BIT_0_MAX:
            decoded_bits += "0"
        elif BIT_1_MIN <= duration <= BIT_1_MAX:
            decoded_bits += "1"
        elif duration >= LETTER_GAP_MIN and duration < COMMAND_GAP_MIN:
            char = bits_to_char(decoded_bits)
            decoded_command += char
            decoded_bits = ""
        elif duration >= COMMAND_GAP_MIN:
            char = bits_to_char(decoded_bits)
            decoded_command += char
            print("Komut tamamlandı:", decoded_command)
            handle_command(decoded_command)
            decoded_command = ""
            decoded_bits = ""

# Başlat
print("SuatPULSE v1.0 - Komut dinleniyor...")
read_pulses()
