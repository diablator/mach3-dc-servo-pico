
import serial
import tkinter as tk

# Seri port ayarı (Pico hangi COM porttaysa buraya yaz)
SERIAL_PORT = "COM5"  # Gerekirse değiştir
BAUDRATE = 115200

def send_command(cmd):
    try:
        with serial.Serial(SERIAL_PORT, BAUDRATE, timeout=1) as ser:
            ser.write((cmd + "\n").encode())
            print("Gönderildi:", cmd)
    except Exception as e:
        print("Hata:", e)

# GUI
root = tk.Tk()
root.title("Pico Servo PID Komut Paneli")

tk.Label(root, text="PID Ayarla (M220)").pack()

entry = tk.Entry(root, width=40)
entry.insert(0, "M220 P1.2 I0.01 D0.1")
entry.pack()

tk.Button(root, text="Gönder (M220)", command=lambda: send_command(entry.get())).pack(pady=5)
tk.Button(root, text="EEPROM Kaydet (M210)", command=lambda: send_command("M210")).pack()
tk.Button(root, text="EEPROM Yükle (M211)", command=lambda: send_command("M211")).pack()

tk.Label(root, text="").pack()
tk.Button(root, text="Çıkış", command=root.quit).pack()

root.mainloop()
